package cn.seecoder.courselearning.po.post;

import cn.seecoder.courselearning.vo.post.PostVO;
import lombok.Getter;
import java.util.Date;

public class Post {
    private Integer id;
    private Date postTime;
    private String title;
    private String content;
    private Integer courseId;
    private Integer userId;
    private String userName;
    private Date replyTime;
    public Post(PostVO postVO){
        id=postVO.getId();
        postTime=postVO.getPostTime();
        title=postVO.getTitle();
        content=postVO.getContent();
        courseId=postVO.getCourseId();
        userId=postVO.getUserId();
        userName=postVO.getUserName();
        replyTime=postVO.getReplyTime();

    }

    public Post(Integer id1,Integer courseId1,Integer userId1,String username,String title1,String content1,Date postTime1,Date replytime) {
        id=id1;
        postTime=postTime1;
        title=title1;
        content=content1;
        courseId=courseId1;
        userId=userId1;
        userName=username;
        replyTime=replytime;

    }


    public Integer getId() {
        return id;
    }

    public Date getPostTime() {
        return postTime;
    }

    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }

    public Integer getcourseId() {
        return courseId;
    }

    public Integer getuserId() {
        return userId;
    }

    public String getuserName() {
        return userName;
    }

    public Date getreplyTime() {
        return replyTime;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public void setReplyTime(Date replyTime) {
        this.replyTime = replyTime;
    }
}
