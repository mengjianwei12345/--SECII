package cn.seecoder.courselearning.vo.user;

import lombok.Data;

@Data
public class UserFormVO {
    private String phone;
    private String password;
}
