package cn.seecoder.courselearning.mapperservice.comment;

import cn.seecoder.courselearning.enums.CommentType;
import cn.seecoder.courselearning.po.comment.Comment;
import cn.seecoder.courselearning.po.post.Post;
import cn.seecoder.courselearning.vo.ResultVO;

import java.sql.Time;
import java.util.Date;
import java.util.List;
/*
/*
 private Integer commentId;
    private CommentType type;
    private Integer receiverId;
    private Integer authorId;
    private String content;
    private Integer postId;
    private Date timeStamp;


 */
public interface CommentMapper {


    public Comment updateComment(Integer commentId, Integer receiverId, Integer authorId, String content, Integer postId, Date timeStamp);
    //根据帖子ID查找回复
    public List<Comment> selectByPostId(Integer postId);
    //根据评论ID查找回复
    public List<Comment> selectByReceiverId(Integer receiverId);
    public ResultVO<String> deleteByPrimaryKey(Integer commentId);
    public int updateByPrimaryKey(Comment record);
    //插入新的回复记录
    public int insert(Comment record);
    //得到某一post或comment的回复消息
    public Comment selectByPrimaryKey(Integer commentId);
    //得到所有的评论消息
    public List<Comment> selectAll();

}
