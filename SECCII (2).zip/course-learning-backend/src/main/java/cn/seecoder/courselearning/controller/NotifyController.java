package cn.seecoder.courselearning.controller;

import cn.seecoder.courselearning.po.notify.Notify;
import cn.seecoder.courselearning.service.notify.NotifyService;
import cn.seecoder.courselearning.service.post.PostService;
import cn.seecoder.courselearning.vo.Notify.NotifyVO;
import cn.seecoder.courselearning.vo.ResultVO;
import cn.seecoder.courselearning.vo.post.PostVO;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@RestController
@RequestMapping("/notify")
public class NotifyController {
    @Resource
    private NotifyService notifyService;

    /**
     * 根据用户Id获取通知列表
     * @param userId 用户id
     */
    @GetMapping("/user/{userId}")
    public List<NotifyVO> getNotifys(@PathVariable Integer userId) {
        return notifyService.getAllNotifys(userId);
    }
    /**
     * 根据用户Id获取通知列表数量
     * @param userId 用户id
     */
    @GetMapping("/user/number/{userId}")
    public int getNotifysnum(@PathVariable Integer userId) {
        return notifyService.getAllNotifys(userId).size();
    }

    /**
     * 创建通知
     * @param notifyVO
     */
    @PostMapping("/create")
    public ResultVO<NotifyVO> createNotify(@RequestBody NotifyVO notifyVO){
        return notifyService.createNotify(notifyVO);
    }


    /**
     * 用户删除通知
     * @param notifyId 评论ID
     */
    @PostMapping("/delete/{notifyId}")
    public ResultVO<String> deleteNotify(@PathVariable Integer notifyId){

        return notifyService.deleteById(notifyId);
    }

}
