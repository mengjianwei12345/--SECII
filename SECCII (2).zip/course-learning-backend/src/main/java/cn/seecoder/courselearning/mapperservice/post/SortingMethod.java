package cn.seecoder.courselearning.mapperservice.post;

public interface SortingMethod {


}
