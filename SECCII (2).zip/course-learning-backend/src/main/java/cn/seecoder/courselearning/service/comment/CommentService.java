package cn.seecoder.courselearning.service.comment;

import cn.seecoder.courselearning.enums.CommentType;
import cn.seecoder.courselearning.po.course.Course;
import cn.seecoder.courselearning.vo.ResultVO;
import cn.seecoder.courselearning.vo.comment.CommentVO;
import cn.seecoder.courselearning.vo.course.CourseVO;
import cn.seecoder.courselearning.vo.post.PostVO;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;

import java.util.List;
/*
 private Integer commentId;
    private CommentType type;
    private Integer receiverId;
    private Integer authorId;
    private String content;
    private Integer postId;
    private Date timeStamp;

 */
@Service("commentService")
public interface CommentService {
    //创建评论
    ResultVO<CommentVO> createComment(CommentVO comment);

    //得到某一评论
    CommentVO getComment(Integer commentId);

    //得到评论列表 根据type两种获取方式
    PageInfo<CommentVO> getAllComments(Integer currPage, Integer pageSize, Integer cid,CommentType type);

    ResultVO<String> deleteComment(Integer commentId);
}
