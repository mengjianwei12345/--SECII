package cn.seecoder.courselearning.service.post;

import cn.seecoder.courselearning.mapperservice.post.SortingMethod;
import cn.seecoder.courselearning.vo.ResultVO;
import cn.seecoder.courselearning.vo.comment.CommentVO;
import cn.seecoder.courselearning.vo.post.PostVO;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;

import java.sql.Time;
import java.util.Date;
import java.util.List;
@Service("postService")
public interface PostService {
     ResultVO<PostVO> createPost(PostVO post);

    //用户有权限查看该课程贴子,返回对应课程的贴子按照指定方式排序后的指定页所含贴子
    //public List<PostVO> getPosts(Integer courseId, Integer start, Integer limit, SortingMethod sortingMethod);
    //用户有权限发布/修改该课程贴子;发布/修改贴子、保存相关信息到数据库并返回用户发布/修改的贴子
    //public PostVO savePost(Integer courseId, Integer userId, Date time, String title, String content, int postId);


    List<PostVO> getAllPost(Integer courseId);

    ResultVO<PostVO> updatePost(PostVO post);

    ResultVO<String> deletePost(Integer postId);

    PostVO getPost(Integer postId);
    PageInfo<PostVO> getPostsByType(Integer currPage, Integer pageSize, Integer cid, String type);//
    PageInfo<PostVO> getPostsByTypeTime(Integer currPage, Integer pageSize, Integer cid, String type);//
}
