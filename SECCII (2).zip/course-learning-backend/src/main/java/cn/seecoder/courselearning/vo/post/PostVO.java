package cn.seecoder.courselearning.vo.post;
import cn.seecoder.courselearning.po.post.Post;

import java.util.Date;
public class PostVO {

    private Integer id;
    private Date postTime;
    private String title;
    private String content;
    private Integer courseId;
    private Integer userId;
    private String userName;
    private Date replyTime;//最新一次被评论的时间，每次被评论时都会更新。


    public PostVO(Post post){
        id=post.getId();
        postTime=post.getPostTime();
        title=post.getTitle();
        content=post.getContent();
        courseId=post.getcourseId();
        userId=post.getuserId();
        userName=post.getuserName();
        replyTime=post.getreplyTime();

    }
    public PostVO(  Integer id,
             Date postTime,
             String title,
             String content,
             Integer courseId,
             Integer userId,
             String userName,
             Date replyTime){
        this.id=id;
        this.postTime=postTime;
        this.title=title;
        this.content=content;
        this.courseId=courseId;
        this.userId=userId;
        this.userName=userName;
        this.replyTime=replyTime;

    }
    public PostVO(){

    }
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getPostTime() {
        return postTime;
    }

    public void setPostTime(Date postTime) {
        this.postTime = postTime;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getCourseId() {
        return courseId;
    }

    public void setCourseId(Integer courseId) {
        this.courseId = courseId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Date getReplyTime() {
        return replyTime;
    }

    public void setReplyTime(Date replyTime) {
        this.replyTime = replyTime;
    }

    public void setUploadTime(Date date) {
        this.postTime=date;
    }
}
