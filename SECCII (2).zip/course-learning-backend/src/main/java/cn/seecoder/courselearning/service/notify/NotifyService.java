package cn.seecoder.courselearning.service.notify;

import cn.seecoder.courselearning.vo.Notify.NotifyVO;
import cn.seecoder.courselearning.vo.ResultVO;
import org.springframework.stereotype.Service;

import java.util.List;
@Service("notifyService")
public interface NotifyService {
    ResultVO<NotifyVO> createNotify(NotifyVO notifyVO);//评论的时候调用这个方法
    List<NotifyVO> getAllNotifys(Integer userId);//根据用户Id调用所有的通知

    ResultVO<String> deleteById(Integer notifyId);
}
