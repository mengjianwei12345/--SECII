package cn.seecoder.courselearning.serviceimpl.comment;

import cn.seecoder.courselearning.enums.CommentType;
import cn.seecoder.courselearning.mapperservice.comment.CommentMapper;
import cn.seecoder.courselearning.mapperservice.post.PostMapper;
import cn.seecoder.courselearning.po.comment.Comment;
import cn.seecoder.courselearning.po.course.Course;
import cn.seecoder.courselearning.po.post.Post;
import cn.seecoder.courselearning.service.comment.CommentService;
import cn.seecoder.courselearning.service.notify.NotifyService;
import cn.seecoder.courselearning.util.Constant;
import cn.seecoder.courselearning.util.PageInfoUtil;
import cn.seecoder.courselearning.vo.Notify.NotifyVO;
import cn.seecoder.courselearning.vo.ResultVO;
import cn.seecoder.courselearning.vo.comment.CommentVO;
import cn.seecoder.courselearning.vo.post.PostVO;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
@Service("commentService")
public  class CommentServiceImpl implements CommentService {
    @Resource
    private CommentMapper commentMapper;
    @Resource
    private PostMapper postMapper;
    @Resource
    private NotifyService notifyService;
    public void setCommentMapper(CommentMapper commentMapper) {
        this.commentMapper = commentMapper;
    }
    //评论帖子
    @Override
    public ResultVO<CommentVO> createComment(CommentVO commentVO) {
        commentVO.setCommentTime(new Date());
        Comment comment = new Comment(commentVO);
        //
        if(comment.getReceiverId()==null)comment.setReceiverId(0);
        if(commentMapper.insert(comment) > 0) {
            //判断该评论事针对帖子还是针对评论
            if(comment.getReceiverId()==0){//针对帖子
              int postId=comment.getPostId();
              Post newpost=postMapper.selectByPrimaryKey(postId);//更新帖子回复时间
              newpost.setReplyTime(new Date());
              postMapper.updateByPrimaryKey(newpost);

              String receiverContent=postMapper.selectByPrimaryKey(postId).getContent();
              int reciverId=postMapper.selectByPrimaryKey(postId).getuserId();
              int senderCommentId=comment.getCommentId();
              int senderId=commentMapper.selectByPrimaryKey(senderCommentId).getUserId();
              String senderContent=comment.getContent();
              Date createTime=new Date();
              Date lastTime=createTime;
              NotifyVO notifyVO=new NotifyVO(null,reciverId,postId,null,senderCommentId,senderId,receiverContent,senderContent,createTime,lastTime);
              notifyService.createNotify(notifyVO);
            }
            else{//这是对评论的评论
                int postId=comment.getPostId();
                Post newpost=postMapper.selectByPrimaryKey(postId);//更新帖子回复时间
                newpost.setReplyTime(new Date());
                postMapper.updateByPrimaryKey(newpost);

                int receverCommentId=comment.getReceiverId();
                String receiverContent=commentMapper.selectByPrimaryKey(receverCommentId).getContent();
                int reciverId=commentMapper.selectByPrimaryKey(receverCommentId).getUserId();
                int senderCommentId=comment.getCommentId();
                int senderId=commentMapper.selectByPrimaryKey(senderCommentId).getUserId();
                String senderContent=comment.getContent();
                Date createTime=new Date();
                Date lastTime=createTime;
                NotifyVO notifyVO=new NotifyVO(null,reciverId,null,receverCommentId,senderCommentId,senderId,receiverContent,senderContent,createTime,lastTime);
                notifyService.createNotify(notifyVO);
            }
            //to do接收通知
            return new ResultVO<>(Constant.REQUEST_SUCCESS, "评论成功", new CommentVO(comment));


        }
        return new ResultVO<>(Constant.REQUEST_FAIL, "评论失败");
    }

    @Override
    public PageInfo<CommentVO> getAllComments(Integer currPage, Integer pageSize, Integer cid,CommentType type) {
        //List<Comment> tempList = commentMapper.selectByPostId(cid);
        if(currPage==null || currPage<1) currPage=1;
        PageHelper.startPage(currPage, pageSize);
        PageInfo<Comment> po = null;
        if(type==CommentType.TO_POST){
            po = new PageInfo<>(commentMapper.selectByPostId(cid));
        }
        else if(type==CommentType.TO_COMMENT){
            po = new PageInfo<>(commentMapper.selectByReceiverId(cid));
        }
        return getCommentVOPageInfo(cid, po);
    }

    @Override
    public CommentVO getComment(Integer commentId){
        Comment comment =commentMapper.selectByPrimaryKey(commentId);
        return new CommentVO(comment);
    }


    @Override
    public ResultVO<String> deleteComment(Integer commentId) {
        ResultVO<String> rs= commentMapper.deleteByPrimaryKey(commentId);
        return rs;
    }


    private PageInfo<CommentVO> getCommentVOPageInfo(Integer cid, PageInfo<Comment> po) {
            PageInfo<CommentVO> result = PageInfoUtil.convert(po, CommentVO.class);
        return result;
    }


}
