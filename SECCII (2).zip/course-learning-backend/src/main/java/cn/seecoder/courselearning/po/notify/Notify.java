package cn.seecoder.courselearning.po.notify;

import java.util.Date;

import cn.seecoder.courselearning.vo.Notify.NotifyVO;
import lombok.Getter;
import lombok.Setter;
public class Notify {

    private Integer id;
    private Integer receiverId;
    private Integer postId;
    private Integer receiverCommentId;
    private Integer senderCommentId;
    private Integer senderId;
    private String receiverContent;
    private String senderContent;
    private Date createTime;
    private Date lastTime;

    public Notify(NotifyVO notifyVO){
        this.id = notifyVO.getId();
        this.receiverId = notifyVO.getReceiverId();
        this.postId = notifyVO.getPostId();
        this.receiverCommentId = notifyVO.getReceiverCommentId();
        this.senderCommentId = notifyVO.getSenderCommentId();
        this.senderId = notifyVO.getSenderId();
        this.receiverContent = notifyVO.getReceiverContent();
        this.senderContent = notifyVO.getSenderContent();
        this.createTime = notifyVO.getCreateTime();
        this.lastTime = notifyVO.getLastTime();

    }

    public Notify(Integer id, Integer receiverId, Integer postId, Integer receiverCommentId, Integer senderCommentId, Integer senderId, String receiverContent, String senderContent, Date createTime, Date lastTime) {
        this.id = id;
        this.receiverId = receiverId;
        this.postId = postId;
        this.receiverCommentId = receiverCommentId;
        this.senderCommentId = senderCommentId;
        this.senderId = senderId;
        this.receiverContent = receiverContent;
        this.senderContent = senderContent;
        this.createTime = createTime;
        this.lastTime = lastTime;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getReceiverId() {
        return receiverId;
    }

    public void setReceiverId(Integer receiverId) {
        this.receiverId = receiverId;
    }

    public Integer getPostId() {
        return postId;
    }

    public void setPostId(Integer postId) {
        this.postId = postId;
    }

    public Integer getReceiverCommentId() {
        return receiverCommentId;
    }

    public void setReceiverCommentId(Integer receiverCommentId) {
        this.receiverCommentId = receiverCommentId;
    }

    public Integer getSenderCommentId() {
        return senderCommentId;
    }

    public void setSenderCommentId(Integer senderCommentId) {
        this.senderCommentId = senderCommentId;
    }

    public Integer getSenderId() {
        return senderId;
    }

    public void setSenderId(Integer senderId) {
        this.senderId = senderId;
    }

    public String getReceiverContent() {
        return receiverContent;
    }

    public void setReceiverContent(String receiverContent) {
        this.receiverContent = receiverContent;
    }

    public String getSenderContent() {
        return senderContent;
    }

    public void setSenderContent(String senderContent) {
        this.senderContent = senderContent;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getLastTime() {
        return lastTime;
    }

    public void setLastTime(Date lastTime) {
        this.lastTime = lastTime;
    }

}
