package cn.seecoder.courselearning.enums;

public enum CommentType {
    TO_POST,
    TO_COMMENT
}
