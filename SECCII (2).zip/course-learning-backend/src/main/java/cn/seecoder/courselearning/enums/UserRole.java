package cn.seecoder.courselearning.enums;

public enum UserRole {
    STUDENT,
    TEACHER,
    ADMIN;
}
