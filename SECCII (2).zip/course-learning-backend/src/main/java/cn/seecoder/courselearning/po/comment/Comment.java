package cn.seecoder.courselearning.po.comment;

import cn.seecoder.courselearning.enums.CommentType;
import cn.seecoder.courselearning.enums.CouponScope;
import cn.seecoder.courselearning.enums.CouponType;
import cn.seecoder.courselearning.vo.comment.CommentVO;
import cn.seecoder.courselearning.vo.coupon.CouponVO;

import java.util.Date;
import lombok.AccessLevel;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
public class Comment {
    private Integer commentId;  //本身评论的ID
    private Integer postId;
    private Integer receiverId; //持有评论的ID
    private Integer userId;
    private String content;

    private Date commentTime;

    public Comment(CommentVO commentVO) {
        this.commentId = commentVO.getCommentId();
        this.userId=commentVO.getUserId();
        this.receiverId=commentVO.getReceiverId();
        this.content=commentVO.getContent();
        this.postId=commentVO.getPostId();
        this.commentTime=commentVO.getCommentTime();
    }
    public Comment(Integer commentId, Integer postId, Integer receiverId, Integer userId, String content, Date commentTime) {
        this.commentId =commentId ;
        this.postId=postId;
        this.receiverId=receiverId;
        this.userId=userId;
        this.content=content;
        this.commentTime=commentTime;
    }
//    public Integer getcommentId() {
//        return commentId;
//    }
    public Integer getCommentId() {
        return commentId;
    }
    public Integer getReceiverId() {
        return receiverId;
    }
//    public Integer getreceiverId() {
//        return receiverId;
//    }
    public Integer getUserId() {
        return userId;
    }
//    public Integer getuserId() {
//        return userId;
//    }
    public String getContent() {
        return content;
    }
//    public String getcontent() {
//        return content;
//    }
//    public Date getcommentTime() {
//        return commentTime;
//    }
//    public Integer getpostId() {
//        return postId;
//    }
    public Integer getPostId() {
        return postId;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public void setCommentTime(Date commentTime) {
        this.commentTime = commentTime;
    }

    public Date getCommentTime() {
        return commentTime;
    }

    public void setCommentId(Integer commentId) {
        this.commentId = commentId;
    }

    public void setPostId(Integer postId) {
        this.postId = postId;
    }

    public void setReceiverId(Integer receiverId) {
        this.receiverId = receiverId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

}
