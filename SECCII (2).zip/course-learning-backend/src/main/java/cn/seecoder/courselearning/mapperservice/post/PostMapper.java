package cn.seecoder.courselearning.mapperservice.post;

import cn.seecoder.courselearning.po.comment.Comment;
import cn.seecoder.courselearning.po.course.Course;
import cn.seecoder.courselearning.po.post.Post;

import java.sql.Time;
import java.util.Date;
import java.util.List;

public interface PostMapper {
    public List<Post> selectByClassId(Integer classId);
    //TODO
    public Post updatePost(Integer id, Date replyToime);
    public List<Comment> selectByPost(Post post);
    int deleteByPrimaryKey(Integer id);
    int insert(Post record);
    Post selectByPrimaryKey(Integer id);
    List<Post> selectAll();
    int updateByPrimaryKey(Post record);


    List<Post> selectByCourseId(Integer courseId);

    List<Post> selectByTimeSequence(Integer courseId);//根据帖子发表的时间正序排列
    List<Post> selectByTimeReverse(Integer courseId);//根据帖子发表的时间倒序排列

    List<Post> selectByReplyTimeSequence(Integer courseId);//根据帖子最近一次被回复的时间正序排列
    List<Post> selectByReplyTimeReverse(Integer courseId);//根据帖子最近一次被回复的时间倒序排列
}
