package cn.seecoder.courselearning.serviceimpl.notify;

import cn.seecoder.courselearning.mapperservice.notify.NotifyMapper;
import cn.seecoder.courselearning.po.notify.Notify;
import cn.seecoder.courselearning.service.notify.NotifyService;
import cn.seecoder.courselearning.util.Constant;
import cn.seecoder.courselearning.vo.Notify.NotifyVO;
import cn.seecoder.courselearning.vo.ResultVO;
import cn.seecoder.courselearning.vo.comment.CommentVO;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
@Service("notifyService")
public class NotifyServiceImpl implements NotifyService {
    @Resource
    private NotifyMapper notifyMapper;
    public ResultVO<NotifyVO> createNotify(NotifyVO notifyVO){
        Notify notify = new Notify(notifyVO);
        if(notifyMapper.insert(notify) > 0)
            return new ResultVO<>(Constant.REQUEST_SUCCESS, "通知创建成功", new NotifyVO(notify));
        return new ResultVO<>(Constant.REQUEST_FAIL, "通知创建失败");
    }
    public List<NotifyVO> getAllNotifys(Integer userId){
        List<Notify> tempList = notifyMapper.selectByReceiverId(userId);
        List<NotifyVO> ret = new ArrayList<>();
        for(Notify notify: tempList){
            ret.add(new NotifyVO(notify));
        }
        return ret;
    }

    @Override
    public ResultVO<String> deleteById(Integer notifyId) {
        if(notifyMapper.deleteByPrimaryKey(notifyId)==1)return new ResultVO<String>(Constant.REQUEST_SUCCESS, "删除成功");
        else return new ResultVO<String>(Constant.REQUEST_FAIL, "删除失败");

    }
}
