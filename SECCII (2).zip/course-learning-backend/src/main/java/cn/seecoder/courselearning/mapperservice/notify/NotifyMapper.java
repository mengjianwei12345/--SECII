package cn.seecoder.courselearning.mapperservice.notify;

import cn.seecoder.courselearning.po.notify.Notify;
import cn.seecoder.courselearning.vo.ResultVO;

import java.util.List;

public interface NotifyMapper {
    int deleteByPrimaryKey(Integer id);



    Notify selectByPrimaryKey(Integer id);

    List<Notify> selectAll();

    //create插入新的通知消息
    int insert(Notify record);

    //更新某个人的所有通知序列
    int updateByReceiverId(int receiverId);

    //得到某个人的所有通知序列
    List<Notify> selectByReceiverId(int receiverId);

    //根据时间降序排列得到通知序列
    List<Notify> selectByTimeSequence(int receiverId);
}
