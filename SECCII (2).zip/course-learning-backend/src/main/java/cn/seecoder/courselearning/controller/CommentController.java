package cn.seecoder.courselearning.controller;

import cn.seecoder.courselearning.enums.CommentType;
import cn.seecoder.courselearning.service.comment.CommentService;
import cn.seecoder.courselearning.service.course.CourseWareService;
import cn.seecoder.courselearning.util.Constant;
import cn.seecoder.courselearning.vo.ResultVO;
import cn.seecoder.courselearning.vo.comment.CommentVO;
import cn.seecoder.courselearning.vo.course.CourseWareVO;
import cn.seecoder.courselearning.vo.order.CourseOrderVO;
import com.github.pagehelper.PageInfo;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;
@RestController
@RequestMapping("/comment")
public class CommentController {
    @Resource
    private CommentService commentService;

    /**
     * 获取单个评论的信息
     * @param commentId 评论ID
     */
    @GetMapping("/{commentId}")
    public CommentVO getComment(
                                @PathVariable Integer commentId) {
        CommentVO commentVO=commentService.getComment(commentId);
        return commentVO;

    }
    /**
     * 获取Post评论列表
     * @param postId 原帖ID
     */
    @GetMapping("/post/{postId}")
    public PageInfo<CommentVO> getCommentsByPost(@RequestParam Integer page,
                                                 @PathVariable Integer postId) {
        return commentService.getAllComments(page, Constant.COURSE_PAGE_SIZE,postId, CommentType.TO_POST);
    }

    /**
     * 获取Comment的评论列表
     * @param commentId comment的ID
     */
    @GetMapping("/comment/{commentId}")
    public PageInfo<CommentVO> getCommentsByComment(@RequestParam  Integer page,
                                                    @PathVariable Integer commentId) {
        return commentService.getAllComments(page, Constant.COURSE_PAGE_SIZE,commentId,CommentType.TO_COMMENT);
    }

    /**
     * 用户发表评论
     * @param comment 评论VO
     */
    @PostMapping("/create")
    public ResultVO<CommentVO> createComment(@RequestBody CommentVO comment){
        CommentVO commentVO=comment;
        return commentService.createComment(commentVO);
    }


    /**
     * 用户删除评论
     * @param commentId 评论ID
     */
    @PostMapping("/delete/{commentId}")
    public ResultVO<String> deleteComment(@PathVariable Integer commentId){
        return commentService.deleteComment(commentId);
    }


}
