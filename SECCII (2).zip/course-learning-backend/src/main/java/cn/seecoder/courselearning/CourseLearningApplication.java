package cn.seecoder.courselearning;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CourseLearningApplication {

    public static void main(String[] args) {
        SpringApplication.run(CourseLearningApplication.class, args);
    }

}
