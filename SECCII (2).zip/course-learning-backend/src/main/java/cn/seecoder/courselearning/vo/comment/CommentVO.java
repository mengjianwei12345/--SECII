package cn.seecoder.courselearning.vo.comment;

import cn.seecoder.courselearning.enums.CommentType;
import cn.seecoder.courselearning.po.comment.Comment;

import java.util.Date;
import lombok.AccessLevel;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
public class CommentVO {
    private Integer commentId;  //本身的ID
    private Integer postId;//被评论的帖子ID
    private Integer receiverId; //持有评论的ID/被评论的评论ID
    private Integer userId;//发表这条评论的用户
    private String content;//评论的内容

    private Date commentTime;//评论发表时间

    public CommentVO(){

    }
    public CommentVO(Integer commentId, Integer postId, Integer receiverId, Integer userId, String content, Date commentTime) {
        this.commentId =commentId ;
        this.postId=postId;
        this.receiverId=receiverId;
        this.userId=userId;
        this.content=content;
        this.commentTime=commentTime;
    }
    public CommentVO(Comment comment){
        this.commentId=comment.getCommentId();
        this.receiverId=comment.getReceiverId();
        this.userId=comment.getUserId();
        this.content=comment.getContent();
        this.commentTime=comment.getCommentTime();
        this.postId=comment.getPostId();
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public void setReceiverId(Integer receiverId) {
        this.receiverId = receiverId;
    }

    public void setCommentId(Integer commentId) {
        this.commentId = commentId;
    }

    public Integer getCommentId() {
        return commentId;
    }

    public void setPostId(Integer postId) {
        this.postId = postId;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Integer getUserId() {
        return userId;
    }

    public Integer getPostId() {
        return postId;
    }

    public Integer getReceiverId() {
        return receiverId;
    }

    public String getContent() {
        return content;
    }

    public Date getCommentTime() {
        return commentTime;
    }

    public void setCommentTime(Date commentTime) {
        this.commentTime = commentTime;
    }

}
