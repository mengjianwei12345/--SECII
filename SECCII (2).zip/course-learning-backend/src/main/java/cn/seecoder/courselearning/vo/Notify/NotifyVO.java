package cn.seecoder.courselearning.vo.Notify;

import cn.seecoder.courselearning.po.notify.Notify;

import java.util.Date;

public class NotifyVO {
    private Integer id;//通知的ID
    private Integer receiverId;//应该收到这条通知的用户ID
    private Integer postId;//被评论的帖子
    private Integer receiverCommentId;//被评论的评论
    private Integer senderCommentId;//发表的评论ID
    private Integer senderId;//引起通知的评论的发表用户
    private String receiverContent;//被评论的内容
    private String senderContent;//评论的内容
    private Date createTime;//通知的时间
    private Date lastTime;//如果与createTime相同说明没有查看过这条通知，否则表明查看过这条通知。查看通知时这个时间被更新

    public NotifyVO(){}
    public NotifyVO(Notify notify){
        this.id=notify.getId();
        this.receiverId=notify.getReceiverId();
        this.postId = notify.getPostId();
        this.receiverCommentId = notify.getReceiverCommentId();
        this.senderCommentId = notify.getSenderId();
        this.senderId = notify.getSenderId();
        this.receiverContent = notify.getReceiverContent();
        this.senderContent = notify.getSenderContent();
        this.createTime = notify.getCreateTime();
        this.lastTime = notify.getLastTime();
    }

    public NotifyVO(Integer id, Integer receiverId, Integer postId, Integer receiverCommentId, Integer senderCommentId, Integer senderId, String receiverContent, String senderContent, Date createTime, Date lastTime) {
        this.id = id;
        this.receiverId = receiverId;
        this.postId = postId;
        this.receiverCommentId = receiverCommentId;
        this.senderCommentId = senderCommentId;
        this.senderId = senderId;
        this.receiverContent = receiverContent;
        this.senderContent = senderContent;
        this.createTime = createTime;
        this.lastTime = lastTime;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getReceiverId() {
        return receiverId;
    }

    public void setReceiverId(Integer receiverId) {
        this.receiverId = receiverId;
    }

    public Integer getPostId() {
        return postId;
    }

    public void setPostId(Integer postId) {
        this.postId = postId;
    }

    public Integer getReceiverCommentId() {
        return receiverCommentId;
    }

    public void setReceiverCommentId(Integer receiverCommentId) {
        this.receiverCommentId = receiverCommentId;
    }

    public Integer getSenderCommentId() {
        return senderCommentId;
    }

    public void setSenderCommentId(Integer senderCommentId) {
        this.senderCommentId = senderCommentId;
    }

    public Integer getSenderId() {
        return senderId;
    }

    public void setSenderId(Integer senderId) {
        this.senderId = senderId;
    }

    public String getReceiverContent() {
        return receiverContent;
    }

    public void setReceiverContent(String receiverContent) {
        this.receiverContent = receiverContent;
    }

    public String getSenderContent() {
        return senderContent;
    }

    public void setSenderContent(String senderContent) {
        this.senderContent = senderContent;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getLastTime() {
        return lastTime;
    }

    public void setLastTime(Date lastTime) {
        this.lastTime = lastTime;
    }

}
