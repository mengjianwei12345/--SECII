package cn.seecoder.courselearning.serviceimpl.post;

import cn.seecoder.courselearning.mapperservice.post.PostMapper;
import cn.seecoder.courselearning.po.post.Post;
import cn.seecoder.courselearning.service.post.PostService;
import cn.seecoder.courselearning.util.Constant;
import cn.seecoder.courselearning.util.PageInfoUtil;
import cn.seecoder.courselearning.vo.ResultVO;
import cn.seecoder.courselearning.vo.post.PostVO;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
@Service("postService")
public class PostServiceImpl implements PostService {
    @Resource
    private PostMapper postMapper;

    public void setPostMapper(PostMapper postMapper) {
        this.postMapper = postMapper;
    }

    @Override
    public ResultVO<PostVO> createPost(PostVO postVO) {
        postVO.setUploadTime(new Date());
        Post post = new Post(postVO);
        if(postMapper.insert(post) > 0)
            return new ResultVO<>(Constant.REQUEST_SUCCESS, "帖子创建成功", new PostVO(post));
        return new ResultVO<>(Constant.REQUEST_FAIL, "帖子创建失败");

    }

//    @Override
//    public List<PostVO> getPosts(Integer courseId, Integer start, Integer limit, SortingMethod sortingMethod) {
//        return null;
//    }
//
//    @Override
//    public PostVO savePost(Integer courseId, Integer userId, Date time, String title, String content,int postId) {
//        Post post=new Post(postId,time,title,content,courseId,userId);
//        return new PostVO(post);
//    }

    @Override
    public List<PostVO> getAllPost(Integer courseId) {
        List<Post> tempList = postMapper.selectByCourseId(courseId);
        List<PostVO> ret = new ArrayList<>();
        for(Post post: tempList){
            ret.add(new PostVO(post));
        }
        return ret;
    }
    @Override
    public PostVO getPost(Integer postId) {

        Post post =postMapper.selectByPrimaryKey(postId);
        return new PostVO(post);
    }
    @Override
    public ResultVO<PostVO> updatePost(PostVO postVO) {

        postVO.setUploadTime(new Date());
        Post post = new Post(postVO);
        if(postMapper.updateByPrimaryKey(post) > 0)
            return new ResultVO<>(Constant.REQUEST_SUCCESS, "帖子更新成功", new PostVO(post));
        return new ResultVO<>(Constant.REQUEST_FAIL, "帖子更新失败");
    }

    @Override
    public ResultVO<String> deletePost(Integer postId) {
        if(postMapper.selectByPrimaryKey(postId) == null)
            return new ResultVO<>(Constant.REQUEST_FAIL, "帖子不存在！");
        else
            postMapper.deleteByPrimaryKey(postId);
        return new ResultVO<>(Constant.REQUEST_SUCCESS, "帖子删除成功");
    }


    @Override
    public PageInfo<PostVO> getPostsByType(Integer currPage, Integer pageSize, Integer cid, String type) {
        if(currPage==null || currPage<1) currPage=1;
        if(type.equals("timeOrder")){//正序
            PageHelper.startPage(currPage, pageSize);
            List<Post> posts=postMapper.selectByTimeSequence(cid);
            PageInfo<Post> po = new PageInfo<>(posts);
            return getPostVOPageInfo(cid, po);
        }else{//反序
            PageHelper.startPage(currPage, pageSize);
            List<Post> posts=postMapper.selectByTimeReverse(cid);
            PageInfo<Post> po = new PageInfo<>(posts);
            return getPostVOPageInfo(cid, po);
        }

    }
    @Override
    public PageInfo<PostVO> getPostsByTypeTime(Integer currPage, Integer pageSize, Integer cid, String type) {
        if(currPage==null || currPage<1) currPage=1;
        if(type.equals("timeOrder")){
            PageHelper.startPage(currPage, pageSize);
            List<Post> posts=postMapper.selectByReplyTimeSequence(cid);
            PageInfo<Post> po = new PageInfo<>(posts);
            return getPostVOPageInfo(cid, po);
        }else{
            PageHelper.startPage(currPage, pageSize);
            List<Post> posts=postMapper.selectByReplyTimeReverse(cid);
            PageInfo<Post> po = new PageInfo<>(posts);
            return getPostVOPageInfo(cid, po);
        }
    }
    private PageInfo<PostVO> getPostVOPageInfo(Integer cid, PageInfo<Post> po) {
        PageInfo<PostVO> result = PageInfoUtil.convert(po, PostVO.class);
        return result;
    }
}
