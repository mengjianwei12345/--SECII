package cn.seecoder.courselearning.controller;
import cn.seecoder.courselearning.service.post.PostService;
import cn.seecoder.courselearning.util.Constant;
import cn.seecoder.courselearning.vo.ResultVO;
import cn.seecoder.courselearning.vo.post.PostVO;
import com.github.pagehelper.PageInfo;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;
/*
private Integer id;
    private Date postTime;
    private Date lastCommentTime;
    private String title;
    private String content;
 */

@RestController
@RequestMapping("/post")
public class PostController {
    @Resource
    private PostService postService;

    public void setPostService(PostService postService) {
        this.postService = postService;
    }

    /**
     * 获取单个post的信息
     * @param postId 帖子id
     */


    @GetMapping("/{postId}")
    public PostVO getPost(@PathVariable Integer postId) {
        return postService.getPost(postId);
    }
    /**
     * 根据课程ID获取post列表
     * @param courseId 课程id
     */
    @GetMapping("/course/{courseId}")
    public List<PostVO> getPosts(@PathVariable Integer courseId) {

        return postService.getAllPost(courseId);
    }
    /**
     * 用户创建post
     * @param post 帖子VO
     */
    @PostMapping("/create")
    public ResultVO<PostVO> createPost(@RequestBody PostVO post){
        return postService.createPost(post);
    }
    /**
     * 更新帖子
     * @param post postVO
     */
    @PostMapping("/update")
    public ResultVO<PostVO> updatePost(@RequestBody PostVO post){
        return postService.updatePost(post);
    }
    /**
     * 删除帖子
     * @param postId postId
     */
    @PostMapping("/delete/{postId}")
    public ResultVO<String> deletePost(@PathVariable Integer postId){
        return postService.deletePost(postId);
    }
    /**
     * 根据分类标签(timeOrder,reverseOrder)，获取帖子列表
     * @param courseid 课程id，查找该课程下的帖子
     * @param type 分类标签(timeOrder,reverseOrder)根据贴子发布的时间排序
     * @param page 当前页号
     */
    @GetMapping("/type/{page}")
    public PageInfo<PostVO> getPostsByType(@RequestParam Integer courseid,
                                             @RequestParam String type,
                                             @PathVariable Integer page) {
        PageInfo<PostVO> info=postService.getPostsByType(page, Constant.POSTS_PAGE_SIZE, courseid, type);
        return info;
    }
    /**
     * 根据分类标签(timeOrder,reverseOrder)，获取帖子列表
     * @param courseid 课程id，查找该课程下的帖子
     * @param type 分类标签(timeOrder,reverseOrder)根据帖子最新回复时间排序
     * @param page 当前页号
     */
    @GetMapping("/typetime/{page}")
    public PageInfo<PostVO> getPostsByTypeTime(@RequestParam Integer courseid,
                                                 @RequestParam String type,
                                                 @PathVariable Integer page) {
        PageInfo<PostVO> info=postService.getPostsByTypeTime(page, Constant.POSTS_PAGE_SIZE, courseid, type);
        return info;
    }
}
