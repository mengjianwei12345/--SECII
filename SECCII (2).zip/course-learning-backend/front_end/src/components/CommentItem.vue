<template>
  <div>
    <v-card :color="replyColor" dark>
      <v-card-title class="headline">
        {{ replyItem.title }}
      </v-card-title>
      <v-card-text class="text">
        {{ floorNo }}楼 【ID: {{ replyItem.commentId }}】
        <br />
        [用户]: {{ replyItem.userId }} [回复帖子ID]: {{ replyItem.receiverId
        }}<br />[创建时间]:
        {{ replyItem.commentTime | parseTime }}
        <br />
        [内容]：
        {{ replyItem.content }}
      </v-card-text>
      <div class="text-right">
        <v-btn @click="$emit('commit', replyItem)">回复</v-btn>
      </div>
    </v-card>
  </div>
</template>

<script>
export default {
  name: "PostComment",
  filters: {
    // 时间戳转为字符串
    parseTime(val) {
      return new Date(val).toLocaleString("chinese", { hour12: false });
    }
  },
  props: {
    replyColor: {
      type: String,
      default: "#BCAAA4"
    },
    replyItem: Object,
    floorNo: {
      type: Number
    }
  }
};
</script>

<style scoped></style>
