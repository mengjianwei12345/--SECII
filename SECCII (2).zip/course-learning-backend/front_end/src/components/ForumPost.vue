<!--<template>-->
<!--    <div>-->
<!--        <ul>-->
<!--            <li v-for="(list, i) in list" :data-listId="list.id" :name="list.id" v-bind:key="i">-->
<!--                <div class="Jitems">-->
<!--&lt;!&ndash;                    显示标题&ndash;&gt;-->
<!--                    <div class="Jitems-Title">-->
<!--                        <router-link :to="direct(`course/post/${list.id}`)" :title="list.title" :listId="list.id">{{list.title}}</router-link>-->
<!--                        <i class="icon-good" v-for="(tags,idx) in list.tags" :title="tags.name" :class="tags.mark" v-bind:key="idx">{{tags.text}}</i>-->
<!--                    </div>-->
<!--                    <div class="Jitems-Detail" v-if="list.is_top != 1">-->
<!--                        <h5 class="Jitems-Detail-text" v-html="list.text">杨超越</h5>-->
<!--                    </div>-->
<!--                    <div class="Jitems-Info">-->
<!--                        <div class="JuserInfo fl">-->
<!--                            用户名：-->
<!--                            <a href="javascript:;" class="JuserInfo-people default" :title="list.username">-->
<!--                                {{list.username}}-->
<!--                            </a>-->
<!--                            <br>-->
<!--                            <span class="JuserInfo-time" :title="list.created_at"> 发表时间： {{list.created_at}}</span>-->
<!--                        </div>-->
<!--                        <router-link class="JdataInfo fr" :to="{ name: 'post', params: {'circleId':circleId,'postId': list.id,'onPage':1}}">-->
<!--                            <span class="Jreply"><v-icon src="../images/评论.png"/>评论数： {{list.comment_count}}</span>-->
<!--                        </router-link>-->
<!--                    </div>-->
<!--                </div>-->
<!--            </li>-->
<!--        </ul>-->
<!--    </div>-->
<!--</template>-->

<template>
  <v-card
    :color="courseColor"
    dark
    width="380"
    height="260"
    class="ma-4 pa-2"
    @click="handleGoToDetail"
  >
    <v-card-title class="headline">
      {{ postItem.title }}
    </v-card-title>
    <v-card-text class="text">
      【内容】{{ briefText }}
      <br />
      【楼主】 {{ postItem.userName }}
      <br />
      【创建时间】{{ postItem.postTime | parseTime }}
    </v-card-text>
    <v-card-actions>
      <v-btn text @click="handleGoToDetail">查看详情</v-btn>
    </v-card-actions>
  </v-card>
</template>

<script>
export default {
  name: "ForumPost",
  filters: {
    // 时间戳转为字符串
    parseTime(val) {
      return new Date(val).toLocaleString("chinese", { hour12: false });
    }
  },
  props: {
    courseColor: {
      type: String,
      default: "#BCAAA4"
    },
    postItem: Object
  },
  data() {
    return {
      list: [],
      allTags: [],
      circleId: "",
      cur: 1,
      all: 1,
      pageSize: 20,
      tags: "",
      order: "time",
      ordername: "时间排序",
      drown: false,
      current: -1,
      isCurrent: 0,
      showFlag: -1,
      tumbCurrent: 0,
      show: false,
      scrolled: false,
      isJump: true,
      isSelectMask: false
    };
  },
  methods: {
    direct(link) {
      if (this.$route.path !== link) {
        this.$router.push(link);
      }
    },
    handleGoToDetail() {
      this.$router.push({
        name: "PostPage",
        params: { postId: this.postItem.id }
      });
    },
    goTop: function() {
      var gotoTop = function() {
        var currentPosition =
          document.documentElement.scrollTop || document.body.scrollTop;
        currentPosition -= 80;
        if (currentPosition > 0) {
          window.scrollTo(0, currentPosition);
        } else {
          window.scrollTo(0, 0);
          clearInterval(timer);
          timer = null;
        }
      };
      var timer = setInterval(gotoTop, 50);
    },

    ShowHtml: function(order, page) {
      const vm = this;
      vm.$http({
        url: "//moment.snail.com/api/v1/post/list-of-circle-post",
        method: "jsonp",
        params: {
          circle_id: this.circleId,
          tag_id: this.tags,
          order: order,
          page: page,
          pagesize: this.pageSize
        },
        jsonp: "callback",
        emulateJSON: true,
        headers: {
          "Content-Type": "x-www-from-urlencoded"
        }
      }).then(function(res) {
        for (var i in res.data.list) {
          res.data.list[i]["flag"] = false;
          res.data.list[i]["showindex"] = 0;
        }
        this.list = res.data.list;
        this.all = res.data.totalPage;
        if (res.data.totalPage === 0) {
          this.all = 1;
        }
      });
    }
  },
  computed: {
    briefText: function() {
      return this.postItem.content.length < 60
        ? this.postItem.content
        : this.postItem.content.substring(0, 60) + "...";
    }
  }
};
</script>

<style scoped></style>
