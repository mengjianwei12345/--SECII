export const API_VERSION = "/api";

export const COURSE_MODULE = `${API_VERSION}/course`;
export const POST_MODULE = `${API_VERSION}/post`;
export const COMMENT_MODULE = `${API_VERSION}/comment`;
export const ORDER_MODULE = `${API_VERSION}/course_order`;
export const COURSE_WARE = `${API_VERSION}/course_ware`;
export const FILE_MODULE = `${API_VERSION}/file`;
export const USER_MODULE = `${API_VERSION}/user`;
export const RECHARGE_MODULE = `${API_VERSION}/recharge`;
export const COUPON_MODULE = `${API_VERSION}/coupon`;
export const NOTIFY_MODULE = `${API_VERSION}/notify`;