import axios from "axios";
import { COMMENT_MODULE } from "./_prefix";

/**
 * 获取一门课程 GET /course/{courseId}?uid={uid} 会包含用户是否购买的信息
 * @param {*} payload
 * @returns
 */
export const getCommentById = payload => {
  const { commentId } = payload;
  return axios.get(`${COMMENT_MODULE}/${commentId}`).then(res => {
    return res.data;
  });
};

// 创建评论
export const createComment = payload => {
  return axios.post(`${COMMENT_MODULE}/create`, payload).then(res => {
    return res.data;
  });
};

// 获取评论列表
export const getComment = payload => {
  return axios
    .get(`${COMMENT_MODULE}/post/${payload.postId}`, {
      params: payload
    })
    .then(res => {
      return res.data;
    });
};

// 查看评论详情
export const getCommentDetail = payload => {
  return axios.get(`${COMMENT_MODULE}/${payload.commentId}`).then(res => {
    return res.data;
  });
};

//获取Comment的评论列表
export const getCommentReply = payload => {
  return axios
    .get(`${COMMENT_MODULE}/comment/${payload.commentId}`, {
      params: payload
    })
    .then(res => {
      return res.data;
    });
};
