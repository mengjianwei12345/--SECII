import axios from "axios";
import { COURSE_MODULE, POST_MODULE,NOTIFY_MODULE } from "./_prefix";

/**
 * 贴子详情
 * @param {*} payload
 * @returns
 */
export const getPostById = payload => {
  const { postId } = payload;
  return axios.get(`${POST_MODULE}/${postId}`).then(res => {
    return res.data;
  });
};

/**
 * 根据关键字 分页获取课程列表 GET /course/all/{page}?uid={uid}&key={key}
 * @param {*} payload
 * @returns
 */
export const getCoursesByKey = payload => {
  const { uid, key, page } = payload;
  return axios
    .get(`${COURSE_MODULE}/all/${page}?uid=${uid}&key=${key}`)
    .then(res => {
      return res.data;
    });
};


export const getNotisByUserid = uid => {
  return axios
      .get(`${NOTIFY_MODULE}/user/${uid}`, {
        params: { uid }
      })
      .then(res => {
        return res.data;
      });
};

/**
 * 点赞课程

 * @param notifyId
 * @returns {Promise<*>}
 */
export const deleteNotification = (notifyId) => {
  return axios
      .post(`${NOTIFY_MODULE}/delete/${notifyId}`)
      .then(res => {
        return res.data;
      });
};

// export const getNotifyNum = (userId) => {
//   console.log( "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
//
//   return axios
//     .get(`${NOTIFY_MODULE}/user/number/${userId}`)
//     .then(res => {
//       console.log("getNotifyNum:!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
//       console.log(res.data);
//       return res.data;
//     });
// };
/**
 * 根据课程分类 分页获取课程列表 GET course/type/{page}?uid={uid}&type={type}
 * @param {*} payload
 * @returns
 */
export const getCoursesByType = payload => {
  const { uid, type, page } = payload;
  return axios
    .get(`${COURSE_MODULE}/type/${page}?uid=${uid}&type=${type}`)
    .then(res => {
      return res.data;
    });
};

/**
 * 获取用户已购买的课程列表 GET course/sid/{sid}
 * @param {*} uid
 * @returns
 */
export const getBoughtCourses = uid => {
  return axios.get(`${COURSE_MODULE}/sid/${uid}`).then(res => {
    return res.data;
  });
};

export const getTeacherCourses = uid => {
  return axios.get(`${COURSE_MODULE}/tid/${uid}`).then(res => {
    return res.data;
  });
};

/**
 * 创建一门帖子 POST course/create
 * @param {*} payload
 * @returns
 */
export const createPost = payload => {
  return axios.post(`${POST_MODULE}/create`, payload).then(res => {
    return res.data;
  });
};

/**
 * 查询帖子，回复时间排序 POST course/create
 * @returns
 */
export const getPostReplyTime = params => {
  return axios
    .get(`${POST_MODULE}/typetime/${params.page}`, {
      params
    })
    .then(res => {
      return res.data;
    });
};

/**
 * 查询帖子，发布时间排序 POST course/create
 * @returns
 */
export const getPostPostTime = params => {
  return axios
    .get(`${POST_MODULE}/type/${params.page}`, {
      params
    })
    .then(res => {
      return res.data;
    });
};

/**
 * 获取热门课程
 * @returns {Promise<*>}
 */
// export const getHotCourses = uid => {
//   return axios
//     .get(`${COURSE_MODULE}/hot/1`, {
//       params: { uid }
//     })
//     .then(res => {
//       return res.data;
//     });
// };

/**
 * 点赞课程
 * @param uid
 * @param courseId
 * @returns {Promise<*>}
 */
// export const setCourseLike = (uid, courseId) => {
//   return axios
//     .post(`${COURSE_MODULE}/like/${courseId}?uid=${uid}`)
//     .then(res => {
//       return res.data;
//     });
// };
//
// export const cancelCourseLike = (uid, courseId) => {
//   return axios
//     .post(`${COURSE_MODULE}/cancel_like/${courseId}?uid=${uid}`)
//     .then(res => {
//       return res.data;
//     });
// };
