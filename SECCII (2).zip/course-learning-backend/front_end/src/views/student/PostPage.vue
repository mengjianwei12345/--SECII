<template>
  <div>
    <v-row>
      <v-col cols="6">
        <v-container
            fluid
            v-for="(item, index) in comment.list"
            v-bind:key="index"
        >
          <v-row class="mt-2 mb-8" cols="16">
            <v-col>
              <reply-item
                  cols="12"
                  md="8"
                  :floorNo="
                  (comment.currentPage - 1) * comment.pageSize + index + 1
                "
                  :reply-item="item"
              >
              </reply-item>
            </v-col>
          </v-row>
        </v-container>
        <v-pagination
            class="mt-4"
            v-model="comment.currentPage"
            :length="comment.totalPage"
            circle
        ></v-pagination>
      </v-col>
      <v-col cols="6">
        <div class="mt-14 mr-10">
          <v-row class="pr-5 ">
            <v-card
                :color="mainItemColor"
                dark
                cols="12"
                md="800"
                width="1200"
                class="ml-6"
            >
              <v-card-title class="headline">
                {{ mainItem.title }}
              </v-card-title>
              <v-card-text class="text">
                【楼主】 {{ mainItem.userName }}
                <br />
                【发表时间】 {{ mainItem.postTime | parseTime }}
                <br />
                【内容】 {{ mainItem.content }}
              </v-card-text>
            </v-card>
            <!--        <v-card :color="mainItemColor" dark cols="12"-->
            <!--                md="800" width="100">-->
            <!--            <v-card-title class="headline">-->
            <!--                {{ mainItem.title }}-->
            <!--            </v-card-title>-->
            <!--        </v-card>-->
            <v-btn
                v-if="!isReply"
                class="mx-6 mt-10 align-self-mid"
                dark
                x-large
                color="green"
                @click="createReply"
            >
              <span class="align-self-center">回复楼主</span>
              <v-icon dark>
                mdi-marker
              </v-icon>
            </v-btn>
            <v-btn
                v-else
                class="mx-6 mt-10 align-self-left"
                dark
                x-large
                color="crimson"
                @click="createReply"
            >
              <span class="align-self-center">取消回复</span>
              <v-icon dark>
                mdi-marker-cancel
              </v-icon>
            </v-btn>
          </v-row>
          <div v-if="isReply">
            <!-- alert -->
            <v-alert
                class="alert mt-8"
                outlined
                type="success"
                text
                v-show="showSuccessDialog"
                transition="scroll-y-transition"
            >
              评论帖子成功！
            </v-alert>
            <!-- alert -->
            <v-alert
                class="alert mt-8"
                outlined
                type="warning"
                text
                v-show="showFailDialog"
                transition="scroll-y-transition"
            >
              {{ msg }}
            </v-alert>
            <v-container class="pl-16 pr-16">
              <form class="pa-12 grey lighten-5 mt-8">
                <!--                <v-text-field v-model="replyTo" label="回复："></v-text-field>-->
                <v-textarea
                    v-model="reply.content"
                    label="回帖内容"
                ></v-textarea>
                <v-text>创建时间：{{ time | parseTime }}</v-text>
                <br />
                <v-text>用户名：{{ userName }}</v-text>
                <br />
                <v-btn class="ml-0 mt-8 info" @click="submit">
                  回复
                </v-btn>
              </form>
            </v-container>

            <!-- 提示对话框 -->
          </div>
        </div>
      </v-col>
    </v-row>
  </div>
</template>

<script>
import ReplyItem from "@/components/ReplyItem.vue";
import { getPostById } from "@/api/post";
import { createComment, getComment } from "@/api/comment";

export default {
  filters: {
    // 时间戳转为字符串
    parseTime(val) {
      return new Date(val).toLocaleString("chinese", { hour12: false });
    }
  },
  name: "Post",
  components: {
    ReplyItem
  },
  data() {
    return {
      mainItem: {
        title: "！",
        content: "",
        userName: "",
        postTime: ""
      },
      isReply: false,
      replyTo: "",
      mainItemColor: "#00B0FF",
      itemColor: "#BCAAA4",
      msg: "",
      reply: {
        receiverId: undefined,
        userId: localStorage.getItem("userId"),
        content: "",
        postId: this.$route.params.postId
      },
      dialog: true,
      showSuccessDialog: false,
      showFailDialog: false,
      time: new Date(),
      userName: window.localStorage.getItem("username"),
      comment: {
        totalPage: 1,
        currentPage: 1,
        list: [],
        pageSize: 3
      },
      replyList: [
        {
          id: 1027,
          title: "Stone年货节！狗富贵互相旺，消费满额赠好礼！",
          images: [
            "https://resplay.snail.com/community/18/post/dc49530e2db80ba6d521cca39471242b.png",
            "https://resplay.snail.com/community/18/post/9325bfb0f26e30ace88ab49ae0bb10fd.jpeg",
            "https://resplay.snail.com/community/18/post/0760b9e5c83118648492bbcb1b567d89.jpeg",
            "https://resplay.snail.com/community/18/post/731b720c32bdf0255e9788034d16853c.jpeg"
          ],
          text:
              "&nbsp;即日起至2月9日凡在Stone游戏平台上累计消费满50元即可获赠《逆转：第一章》、满100元获赠《逆转：第二章》、满200元送《领地人生：林中村落》。全场游戏、DLC、方舟月卡及季票均可参加满额活动，满赠游戏奖励不叠加，赠送游戏将在五个工作日内到账。满50元获赠游戏《逆转：第一章》&nbsp;在医院里醒来的你完全失去了记忆……原来你在2035年的布宜诺斯艾利斯市，而整个城市都被一个军事组织控制住了。突然间，你意识到自己身处险境，需要尽快逃跑。你将何去何从？\n《逆转》是由独立游戏工作室3f互动开发的一款科幻题材的鼠标操作冒险游戏。灵感取自于LucasArts，Sierra甚至Pendulo工作室的流派经典，3f互动坚持为传统冒险游戏粉丝们打造游戏。\n  抓住机会改变历史;《逆转》就在现在。满100元获赠游戏《逆转：第二章》&nbsp;&nbsp;逃离医院后你仍然没有记忆。维多利亚正在帮助你找到照片中的人，恢复你的记忆、了解你的真实身份，以及为什么你会在这里至关重要。\n在你的旅途中，你会遇到向你伸出援手的新朋友。在享誉世界的布宜诺斯艾利斯市不断挑战散落各处的新谜题吧。它们会让你一步一步接近那个可能掌握着你所需要的一切答案的神秘人物。\n  你需要记起你究竟是谁。满200元获赠游戏《领地人生：林中村落》&nbsp;&nbsp;《领地人生:林中村落》是一款玩法丰富的城镇建筑类模拟战略生存游戏。带领你的人民，在一个未知的岛屿上发展壮大。\n \n改造和重塑土地，扩建房屋、牧场、果园、农场、风车等各类建筑物。在森林里饲养，寻找猎物，种植庄稼和家畜用作物。\n \n随着冬天袭来，确保你有足够的木材和温暖的衣服。记住，缺乏维生素很可能导致疾病，甚至完全让你的村庄消失！关于Stone：&nbsp;&nbsp;Stone游戏平台是蜗牛游戏研发的华人首个专注精品pc游戏发行平台，该平台致力于在全球范围甄选精品pc游戏，为中国玩家们带来多样的佳作体验。&nbsp;",
          is_top: 1,
          is_official: 0,
          tags: [],
          username: "石头妹",
          user_photo:
              "https://resplay.snail.com/avatar/1000426585587.jpeg?v=1532494396",
          view_count: 670,
          comment_count: 12,
          created_at: "3年前",
          flag: false,
          showindex: 0
        },
        {
          id: 4692,
          title: "请问有客服吗",
          images: [
            "https://img2.baidu.com/it/u=4275020871,2736129555&fm=26&fmt=auto&gp=0.jpg",
            "https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fn.sinaimg.cn%2Fsinakd202079s%2F98%2Fw1080h1418%2F20200709%2Fa44b-iwasyei6614838.jpg&refer=http%3A%2F%2Fn.sinaimg.cn&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1626442458&t=3ae6b4020ea625e4f71adf529b88b440"
          ],
          text: "方舟进去就弹白框，就想问问有没有人管",
          is_top: 0,
          is_official: 0,
          tags: [],
          username: "WN91568255",
          user_photo: "https://resplay.snail.com/avatar/default.png",
          view_count: 6,
          comment_count: 1,
          created_at: "12-05 21:41",
          flag: true,
          showindex: 0
        },
        {
          id: 4656,
          title: "方舟下不了",
          images: [],
          text: "这平台买完月卡 下不了游戏 &nbsp;还不能退款",
          is_top: 0,
          is_official: 0,
          tags: [],
          username: "石头科技-王总",
          user_photo: "https://resplay.snail.com/avatar/default.png",
          view_count: 28,
          comment_count: 3,
          created_at: "10-07 22:39",
          flag: false,
          showindex: 0
        }
      ]
    };
  },
  watch: {
    "comment.currentPage"() {
      this.getComment();
    }
  },
  created: function() {
    this.getDetail(); // 加载详情
    this.getComment();
  },
  methods: {
    // 创建回复
    submit() {
      createComment({
        ...this.reply
      })
          .then(res => {
            console.log(res);
            if (res.code === 1) {
              this.showSuccessDialog = true;
              setTimeout(() => {
                this.showSuccessDialog = false;
              }, 1000);
              this.reply.content = "";
              this.comment.currentPage = 1;
              this.getComment();
            } else {
              this.showFailDialog = true;
              this.msg = res.msg;
              setTimeout(() => {
                this.showFailDialog = false;
              }, 1000);
            }
          })
          .finally(() => {
            this.time = new Date();
          });
    },
    createReply() {
      this.isReply = !this.isReply;
    },
    // 获取评论列表
    getComment() {
      getComment({
        postId: this.$route.params.postId,
        page: this.comment.currentPage
      }).then(res => {
        console.log(res);
        this.comment.list = res.list;
        this.comment.currentPage = res.pageNum;
        this.comment.totalPage = res.pages;
        this.comment.pageSize = res.pageSize;
      });
    },
    // 获取详情
    getDetail() {
      getPostById({ postId: this.$route.params.postId }).then(res => {
        console.log(res);
        this.mainItem = res;
      });
    }
  }
};
</script>

<style scoped></style>
