<template>
  <div>
      <v-chip
        class="ma-2"
        color="deep-purple lighten-3"
        label
        text-color="white"
      >
        <v-icon left>
          mdi-bell-outline
        </v-icon>
        Notification Center
      </v-chip>
    <v-container class="ma-8 pa-4">
      <v-card
        v-for="n in notificationList"
        :key="n.id"
        color="#3355"
        dark
        max-width="2400"
        class="mx-auto ma-4 paa-2"
      >
        <v-card-title>
          <v-icon
            left
          >
            mdi-bell
          </v-icon>

          <span class="text-subtitle-1 font-weight-black">ID为{{n.senderId}}的用户评论了你发表的{{n.receiverCommentId===null? "帖子:" : "评论:" }}</span>
        </v-card-title>
        <v-card-text class="text-h7 font-weight-medium">
          ID:{{n.receiverId}}:{{n.receiverCommentId===null? "帖子:" : "评论:" }}"{{briefContent(n.receiverContent) }}"
        </v-card-text>
        <v-card-text class="text-h8 font-weight-medium">
          ID:{{n.senderId}}:"{{ briefContent(n.senderContent) }}"
        </v-card-text>

        <v-card-actions>
          <v-list-item class="grow">
<!--            <v-list-item-avatar color="blue darken-3">-->
<!--&lt;!&ndash;              src="https://avataaars.io/?avatarStyle=Transparent&topType=ShortHairShortCurly&accessoriesType=Prescription02&hairColor=Blue&facialHairType=Blank&clotheType=Hoodie&clotheColor=White&eyeType=Default&eyebrowType=DefaultNatural&mouthType=Default&skinColor=Light"&ndash;&gt;-->

<!--&lt;!&ndash;              <v-img&ndash;&gt;-->
<!--&lt;!&ndash;                class="elevation-6"&ndash;&gt;-->
<!--&lt;!&ndash;                alt=""&ndash;&gt;-->
<!--&lt;!&ndash;                src="https://avataaars.io"></v-img>&ndash;&gt;-->
<!--            </v-list-item-avatar>-->
            <v-list-item-content>
              <v-text>{{ "我的ID："+n.receiverId}}</v-text>
              <v-text>{{ "回复者ID："+n.senderId}}</v-text>
              <v-text>{{n.postId!=null?"原帖ID:"+n.postId:"被评论ID"+n.receiverCommentId}}</v-text>
              <v-text>{{ (n.senderCommentId==null? "帖子ID:"+n.postId : "评论ID:"+n.senderCommentId)}}</v-text>
            </v-list-item-content>
            <v-text>{{"通知时间:"+new Date().toLocaleString("chinese", { hour12: false })| parseTime}}</v-text>
            <v-row
              align="center"
              justify="end"
            >
              <v-btn
                color="black lighten-2"
                text
                @click="gotoPost(n.postId)"
              >
                <v-icon class="mr-1">
                  mdi-google-circles-group
                </v-icon>
                <span class="subheading mr-2">查看被回复的{{(n.receiverCommentId===null? "帖子" : "评论")}}</span>
              </v-btn>
              <span class="mr-1">·</span>
              <v-btn
                color="black lighten-2"
                text
                @click="deleteNotification(n.id)"
              >
                <v-icon class="mr-1">
                  mdi-delete-sweep
                </v-icon>
<!--                <span class="material-icons-outlined">-->
<!--delete_sweep  mdi-trash-can-outline-->
<!--</span>-->
                <span class="subheading">删除通知</span>
              </v-btn>

            </v-row>
          </v-list-item>
        </v-card-actions>
      </v-card>

    </v-container>
<!--    <v-text class="mt-1">-->
<!--      <v-text class="font-weight-thin">@{{ n.username }}{{ space }}:</v-text>-->
<!--      "{{ n.bereplyedbyuser }}" 回复了-->
<!--    </v-text>-->
<!--    <v-text class="font-weight-light">您发表的{{ n.isPostReplied ? "帖子" : "评论" }}</v-text>-->
<!--    <p class="font-weight-regular brown-text" >" {{ briefContent(n.replycontent) }} ":</p>-->

<!--    <p class="text-h5">-->
<!--      <v-text>{{ briefContent(n.berepliedbycontent) }}</v-text>-->
<!--    </p>-->
  </div>
</template>

<script>
import { deleteNotification, getNotisByUserid } from "@/api/post";

export default {
  name: "NotificationCenter",
  filters: {
    // 时间戳转为字符串
    parseTime(val) {
      return new Date(val).toLocaleString("chinese", { hour12:false });
    }
  },
  data() {
    return {
      space: "  ",
      userid: 0,
      colorList: [
        "#FFAB91",
        "#26A69A",
        "#039BE5",
        "red lighten-2",
        "#B39DDB",
        "#EF9A9A"
      ],
      notificationList: [
      ]
    };
  },
  created() {
    const userid = window.localStorage.getItem("userId");
    getNotisByUserid(userid).then(res => {
      console.log(res);
      this.notificationList = res || [];
    });
  },

  methods: {
    gotoPost(postid) {
      this.$router.push(`course/post/${postid}`);
    },
    deleteNotification(id){
      deleteNotification(id);
      getNotisByUserid(id);

    },
    briefContent: function(val) {
      return val.length < 35
        ? val
        : val.substring(0, 35) + "...";
    },
    getNotisByUserid(userid){
      getNotisByUserid(userid).then(res => {
        console.log(res);
        this.notificationList = res || [];
      });
    }
  },
  computed: {
    briefText: function(val) {
      return val.length < 25
        ? val
        : val.substring(0, 25) + "...";
    },

  },
};
</script>
