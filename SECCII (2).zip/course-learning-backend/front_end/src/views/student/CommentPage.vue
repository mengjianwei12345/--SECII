<template>
  <div>
    <v-row>
      <v-col cols="6">
        <v-container
            fluid
            v-for="(item, index) in comment.list"
            v-bind:key="index"
        >
          <v-row class="mt-2 mb-8" cols="16">
            <v-col>
              <CommentItem
                  cols="12"
                  md="8"
                  :floorNo="
                  (comment.currentPage - 1) * comment.pageSize + index + 1
                "
                  @commit="createReply"
                  :reply-item="item"
              >
              </CommentItem>
            </v-col>
          </v-row>
        </v-container>
        <v-pagination
            class="mt-4"
            v-model="comment.currentPage"
            :length="comment.totalPage"
            circle
        ></v-pagination>
      </v-col>
      <v-col cols="6">
        <div class="mt-14 mr-10">
          <v-row class="pr-5 ">
            <v-card
                :color="mainItemColor"
                dark
                cols="12"
                md="800"
                width="1200"
                class="ml-6"
            >
              <v-card-title class="headline">
                {{ mainItem.title }}
              </v-card-title>
              <v-card-text class="text">
                【用户】 {{ mainItem.userId }}
                <br />
                【发表时间】 {{ mainItem.commentTime | parseTime }}
                <br />
                【内容】 {{ mainItem.content }}
              </v-card-text>
            </v-card>
            <v-btn
                v-if="isReply"
                class="mx-6 mt-10 align-self-left"
                dark
                x-large
                color="crimson"
                @click="createReply()"
            >
              <span class="align-self-center">取消回复</span>
              <v-icon dark>
                mdi-marker-cancel
              </v-icon>
            </v-btn>
          </v-row>
          <div v-if="isReply">
            <!-- alert -->
            <v-alert
                class="alert mt-8"
                outlined
                type="success"
                text
                v-show="showSuccessDialog"
                transition="scroll-y-transition"
            >
              评论帖子成功！
            </v-alert>
            <!-- alert -->
            <v-alert
                class="alert mt-8"
                outlined
                type="warning"
                text
                v-show="showFailDialog"
                transition="scroll-y-transition"
            >
              {{ msg }}
            </v-alert>
            <v-container class="pl-16 pr-16">
              <form class="pa-12 grey lighten-5 mt-8">
                <v-text-field
                    :value="
                    `用户ID：${currentComment.userId} / 帖子ID：${currentComment.commentId}`
                  "
                    label="回复："
                    readonly
                ></v-text-field>
                <v-textarea
                    v-model="reply.content"
                    label="回帖内容"
                ></v-textarea>
                <v-text>创建时间：{{ time | parseTime }}</v-text>
                <br />
                <v-text>用户名：{{ userName }}</v-text>
                <br />
                <v-btn class="ml-0 mt-8 info" @click="submit">
                  回复
                </v-btn>
              </form>
            </v-container>

            <!-- 提示对话框 -->
          </div>
        </div>
      </v-col>
    </v-row>
  </div>
</template>

<script>
import {
  createComment,
  getCommentDetail,
  getCommentReply
} from "@/api/comment";
import CommentItem from "@/components/CommentItem";

export default {
  filters: {
    // 时间戳转为字符串
    parseTime(val) {
      return new Date(val).toLocaleString("chinese", { hour12: false });
    }
  },
  name: "Post",
  components: {
    CommentItem
  },
  data() {
    return {
      mainItem: {
        title: "！",
        content: "",
        userName: "",
        postTime: ""
      },
      isReply: true,
      replyTo: "",
      mainItemColor: "#00B0FF",
      itemColor: "#BCAAA4",
      msg: "",
      reply: {
        receiverId: undefined,
        userId: localStorage.getItem("userId"),
        content: "",
        postId: this.$route.params.postId
      },
      dialog: true,
      showSuccessDialog: false,
      showFailDialog: false,
      time: new Date(),
      userName: window.localStorage.getItem("username"),
      comment: {
        totalPage: 1,
        currentPage: 1,
        list: [],
        pageSize: 3
      },
      currentComment: {}
    };
  },
  watch: {
    "comment.currentPage"() {
      this.getComment();
    }
  },
  created: function() {
    this.getDetail(); // 加载详情
    this.getComment();
  },
  methods: {
    // 创建回复
    submit() {
      createComment({
        ...this.reply,
        receiverId: this.currentComment.commentId
      })
          .then(res => {
            console.log(res);
            if (res.code === 1) {
              this.showSuccessDialog = true;
              setTimeout(() => {
                this.showSuccessDialog = false;
              }, 1000);
              this.reply.content = "";
              this.comment.currentPage = 1;
              this.getComment();
            } else {
              this.showFailDialog = true;
              this.msg = res.msg;
              setTimeout(() => {
                this.showFailDialog = false;
              }, 1000);
            }
          })
          .finally(() => {
            this.time = new Date();
          });
    },
    createReply(item) {
      if (item) {
        this.currentComment = item;
        this.isReply = true;
      } else {
        this.isReply = false;
      }
    },
    // 获取评论列表
    getComment() {
      getCommentReply({
        commentId: this.$route.params.commentId,
        page: this.comment.currentPage
      }).then(res => {
        console.log(res);
        this.comment.list = res.list;
        this.comment.currentPage = res.pageNum;
        this.comment.totalPage = res.pages;
        this.comment.pageSize = res.pageSize;
      });
    },
    // 获取详情
    getDetail() {
      getCommentDetail({ commentId: this.$route.params.commentId }).then(
          res => {
            this.mainItem = res;
            this.currentComment = this.mainItem;
          }
      );
    }
  }
};
</script>

<style scoped></style>
