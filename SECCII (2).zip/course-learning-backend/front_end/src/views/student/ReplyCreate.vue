<template>
    <div>
        <!-- alert -->
        <v-alert
                class="alert"
                outlined
                type="success"
                text
                v-show="showSuccessDialog"
                transition="scroll-y-transition"
        >
            评论帖子成功！
        </v-alert>
        <!-- alert -->
        <v-alert
                class="alert"
                outlined
                type="warning"
                text
                v-show="showFailDialog"
                transition="scroll-y-transition"
        >
            {{ msg }}
        </v-alert>
        <v-container class="pl-16 pr-16">
            <form class="pa-12 grey lighten-5 mt-8">
                <v-textarea v-model="courseInfo.intro" label="回帖内容"></v-textarea>
                <v-card-text>创建时间：{{time}}</v-card-text>
                <v-card-text>用户名：{{userName}}</v-card-text>
                <v-btn class="ml-0 mt-8 info" @click="submit">
                    确认
                </v-btn>
            </form>
        </v-container>

        <!-- 提示对话框 -->
    </div>
</template>
<script>
    //import { createCourse } from "@/api/course";

    export default {
        name: "CourseCreate",

        data() {
            return {
                courseInfo: {
                    name: "",
                    type: "初级",
                    intro: "",
                    picture: "course1.png",
                    school: "",
                    cost: 0
                },
                dialog: true,
                showSuccessDialog: false,
                showFailDialog: false,
                msg: "",
                time: "a",
                userName: ""
            };
        },
        mounted: function () {
            let date=new Date();
            this.time=date.toLocaleString('chinese', { hour12: false });
            //this.time="111";
            const uname = window.localStorage.getItem("username");
            this.userName=uname;

        },
        methods: {
            submit() {
                //TODO create a post
                const uid = window.localStorage.getItem("userId");
                const uname = window.localStorage.getItem("username");
                const payload = {
                    ...this.courseInfo,
                    picture: null,
                    teacherId: uid,
                    teacherName: uname,
                    bought: false,
                    manageable: true
                };
                console.log(payload);
                // createCourse(payload).then(res => {
                //     console.log(res);
                //     if (res.code === 1) {
                //         this.showSuccessDialog = true;
                //         setTimeout(() => {
                //             this.showSuccessDialog = false;
                //         }, 1000);
                //     } else {
                //         this.showFailDialog = true;
                //         this.msg = res.msg;
                //         setTimeout(() => {
                //             this.showFailDialog = false;
                //         }, 1000);
                //     }
                // });
            }
        }
    };
</script>

<style scoped>
    .alert {
        position: fixed;
        left: 50%;
        top: 100px;
        z-index: 999;
    }
</style>
