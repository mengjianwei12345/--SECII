<template>
  <div>
    <!-- 分类课程 -->
    <v-row class="mt-2 mb-8 ml-2">
      <v-chip
        class="ma-2"
        color="deep-purple lighten-3"
        label
        text-color="white"
      >
        <v-icon left>
          mdi-label
        </v-icon>
        所有帖子
      </v-chip>
      <div class="" style="flex: 1;text-align: right">
        <v-btn class="mr-10 mt-2 info" @click="createPost">
          发布帖子
        </v-btn>
      </div>
    </v-row>
    <v-card>
      <v-tabs color="deep-purple accent-4" right v-model="currentTab">
        <v-tab>发布时间正序</v-tab>
        <v-tab>发布时间倒序</v-tab>
        <v-tab>回复时间正序</v-tab>
        <v-tab>回复时间倒序</v-tab>
        <v-tab-item
          v-for="c in [
            postListPostTimeAsc,
            postListPostTimeDesc,
            postListReplyTimeAsc,
            postListReplyTimeDesc
          ]"
          :key="c.name"
        >
          <v-container fluid>
            <v-row class="ma-4">
              <forum-post
                cols="12"
                md="4"
                v-for="post in c.list"
                v-bind:key="post.id"
                :post-item="post"
                @goto-detail="goToDetail"
              >
              </forum-post>
            </v-row>
            <v-pagination
              class="mt-4"
              v-model="c.currentPage"
              :length="c.totalPage"
              circle
            ></v-pagination>
          </v-container>
        </v-tab-item>
      </v-tabs>
    </v-card>
  </div>
</template>

<script>
import ForumPost from "@/components/ForumPost.vue";
import { getPostReplyTime, getPostPostTime } from "@/api/post";
export default {
  name: "CourseForum",
  components: {
    ForumPost
  },
  data() {
    return {
      currentTab: 0,
      postListPostTimeAsc: {
        name: "发布时间正序",
        totalPage: 1,
        currentPage: 1,
        list: []
      },
      postListPostTimeDesc: {
        name: "发布时间倒序",
        totalPage: 1,
        currentPage: 1,
        list: []
      },
      postListReplyTimeAsc: {
        name: "回复时间正序",
        totalPage: 1,
        currentPage: 1,
        list: []
      },
      postListReplyTimeDesc: {
        name: "回复时间倒序",
        totalPage: 1,
        currentPage: 1,
        list: []
      }
    };
  },
  watch: {
    "timeOrder.currentPage": {
      handler: function(val) {
        this.handleGetPostsByType(val, "timeOrder");
      }
    },
    "reverseOrder.currentPage": {
      handler: function(val) {
        this.handleGetPostsByType(val, "reverseOrder");
      }
    }
  },

  computed: {
    isCharge: function() {
      return this.courseInfo.cost !== 0;
    }
  },

  methods: {
    initPage() {
      const { courseId } = this.$route.params;
      console.log(courseId);
      // 加载列表
      this.fetch("postListPostTimeAsc");
      this.fetch("postListPostTimeDesc");
      this.fetch("postListReplyTimeAsc");
      this.fetch("postListReplyTimeDesc");
    },
    fetch(type) {
      const { courseId } = this.$route.params;
      let api = null;
      let paramsType = "other";
      if (type === "postListPostTimeAsc" || type === "postListPostTimeDesc") {
        api = getPostPostTime;
      } else {
        api = getPostReplyTime;
      }
      if (type === "postListPostTimeAsc" || type === "postListReplyTimeAsc") {
        paramsType = "timeOrder";
      }
      api({
        courseid: courseId,
        page: this[type].currentPage,
        type: paramsType
      }).then(res => {
        console.log(res);
        res.list;
        this[type].list = res.list;
        // this[type].currentPage = 1;
        this[type].totalPage = res.pages;
      });
    },
    testClick() {
      const { courseId } = this.$route.params;
      console.log(courseId);
    },
    goToDetail() {
      const { courseId } = this.$route.params;
      this.$route.push(`student/course/post/${courseId}`);
    },
    handleGetPostsByType(page, type) {
      this.fetch(type);
    },
    createPost() {
      this.$router.push({
        name: "PostCreate",
        params: { courseId: this.$route.params.courseId }
      });
    }
  },

  mounted() {
    this.initPage();
  }
};
</script>

<style scoped></style>
