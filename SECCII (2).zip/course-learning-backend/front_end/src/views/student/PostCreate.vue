<template>
  <div>
    <!-- alert -->
    <v-alert
      class="alert"
      outlined
      type="success"
      text
      v-show="showSuccessDialog"
      transition="scroll-y-transition"
    >
      帖子创建成功！
    </v-alert>
    <!-- alert -->
    <v-alert
      class="alert"
      outlined
      type="warning"
      text
      v-show="showFailDialog"
      transition="scroll-y-transition"
    >
      {{ msg }}
    </v-alert>
    <v-container class="pl-16 pr-16">
      <form class="pa-12 grey lighten-5 mt-8">
        <v-text-field v-model="postInfo.title" label="帖子主题"></v-text-field>
        <v-textarea v-model="postInfo.content" label="帖子内容"></v-textarea>
        <v-card-text>创建时间：{{ time }}</v-card-text>
        <v-card-text>用户id：{{ userId }}</v-card-text>
        <v-btn class="ml-0 mt-8 info" @click="submit">
          确认
        </v-btn>
      </form>
    </v-container>

    <!-- 提示对话框 -->
  </div>
</template>
<script>
// eslint-disable-next-line no-unused-vars
import { createPost } from "@/api/post";

export default {
  name: "PostCreate",

  data() {
    return {
      userId: localStorage.getItem("userId"),
      postInfo: {
        content: "",
        title: ""
      },
      dialog: true,
      showSuccessDialog: false,
      showFailDialog: false,
      msg: "",
      time: new Date().toLocaleString("chinese", { hour12: false })
    };
  },
  mounted: function() {},
  methods: {
    submit() {
      // const timestamp = parseInt(new Date().getTime() / 1000); // 当前时间戳
      const payload = {
        ...this.postInfo,
        userId: this.userId,
        // postTime: timestamp,
        // replyTime: timestamp,
        userName: localStorage.getItem("username"),
        courseId: this.$route.params.courseId
      };
      console.log(payload);
      createPost(payload)
        .then(res => {
          console.log(res);
          if (res.code === 1) {
            this.showSuccessDialog = true;
            setTimeout(() => {
              this.showSuccessDialog = false;
            }, 1000);
          } else {
            this.showFailDialog = true;
            this.msg = res.msg;
            setTimeout(() => {
              this.showFailDialog = false;
            }, 1000);
          }
        })
        .finally(() => {
          this.postInfo = {
            content: "",
            title: ""
          };
          this.time = new Date().toLocaleString("chinese", { hour12: false });
        });
    }
  }
};
</script>

<style scoped>
.alert {
  position: fixed;
  left: 50%;
  top: 100px;
  z-index: 999;
}
</style>
