<template>
  <div>
    <v-app-bar color="deep-purple lighten-3" dense dark>
      <v-app-bar-nav-icon @click="direct('/student')">
        <v-icon>mdi-home</v-icon></v-app-bar-nav-icon
      >

      <v-toolbar-title @click="direct('/student')" class="cursor">
        Course Learning Student
      </v-toolbar-title>

      <v-spacer></v-spacer>

      <v-menu left bottom>
        <template v-slot:activator="{ on, attrs }">
          <v-btn icon v-bind="attrs" v-on="on">
            <v-icon>mdi-dots-vertical</v-icon>
          </v-btn>
        </template>

        <v-list>
          <v-list-item
            v-for="opt in optionList"
            :key="opt.optionName"
            @click="direct(opt.link)"
          >
            <v-list-item-title>{{ opt.optionName }}</v-list-item-title>
          </v-list-item>
        </v-list>
        <v-btn
            text
            @click="gotoNotificationCenter()"
        >
          <v-badge
            v-if="1>0"
            color="red"
            v-bind:content="0">         
            <v-icon class="mr-1">
              mdi-lightbulb-on
            </v-icon>
          </v-badge>
        </v-btn>
      </v-menu>
    </v-app-bar>
    <router-view />
  </div>
</template>

<script>
//import { getNotifyNum } from "@/api/post";
export default {
  name: "StudentLayout",
  filters: {
    // 时间戳转为字符串
    parseTime(val) {
      return new Date(val).toLocaleString("chinese", { hour12: false });
    }
  },
  data() {
    return {
      optionList: [
        {
          optionName: "历史订单",
          link: "/student/history"
        },
        {
          optionName: "个人中心",
          link: `/student/user/${window.localStorage.getItem("userId")}`
        },
        {
          optionName: "登出",
          link: "/"
        }
      ]
    };
  },
  methods: {
    direct(link) {
      //console.log(this.$route.path)
      if (link === "/") {
        this.logout();
      }
      if (this.$route.path !== link) {
        this.$router.push(link);

      }
    },

    logout() {
      window.localStorage.removeItem("userId");
      window.localStorage.removeItem("userPhone");
      window.localStorage.removeItem("username");
      window.localStorage.removeItem("userRole");
    },gotoNotificationCenter() {
      this.$router.push("/student/notify");
    },
    // getNotifyNum1() {
    //   getNotifyNum(window.localStorage.getItem("userId")).then(res =>{
    //         console.log(res);
    //         res;
    //       }
    //   );
    //
    // }
  }
};
</script>

<style scoped>
.cursor {
  cursor: pointer;
}
</style>
